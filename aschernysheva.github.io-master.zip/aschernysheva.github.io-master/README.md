Anastasia Chernysheva
<br/>
  <html>
    <head>
      Hello World!
      <meta charset="utf-8">
      This is my Page on Github
    </head>
        <br/>
 
    <body> 
      <left><h1> Information: I`m a student of the Higher School of Economic and I`m being proud of it. I hate informatics with all my heart (cause I`m really bad at it and I cannot change the situation). However I`m sure that IT is the most perspective sci-field today, plus Bill Ghates - the founder of Microsoft is the iconic figure for me - I really appreciate him, his projects and more than anything his super progressive ideas regarding politics, bissiness, education etc .</h1></left>
      <br/>
      <h2>How you can contact with me? See the links below </h2>
   <br/>
      My Page on VK https://vk.com/anchernyshyova
       <br/>
      My Page on на GitHub https://github.com/aschernysheva
      <br/>
      <br/>
      Phone number: <b>+79254619981</b>
      <br/>
      E-mail: <i>aschernysheva@edu.hse.ru</i>
    </body>
  </html>
